using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using RaceDay.Api.Models;

namespace RaceDay.Api.Tests;

public class RaceDayModelTests
{
    [Fact]
    public void UserRoles_ExposeTheTwoRequiredRoles()
    {
        Assert.Equal("Organiser", UserRoles.Organiser);
        Assert.Equal("Participant", UserRoles.Participant);
    }

    [Fact]
    public void PasswordHasher_VerifiesAHashedPassword()
    {
        var user = new User { Email = "runner@example.com", FirstName = "A", LastName = "Runner" };
        var hasher = new PasswordHasher<User>();
        user.PasswordHash = hasher.HashPassword(user, "RaceDay!2026");
        Assert.Equal(PasswordVerificationResult.Success, hasher.VerifyHashedPassword(user, user.PasswordHash, "RaceDay!2026"));
        Assert.Equal(PasswordVerificationResult.Failed, hasher.VerifyHashedPassword(user, user.PasswordHash, "WrongPassword"));
    }

    [Fact]
    public void Event_RequiresANameAndVenue()
    {
        var ev = new RaceDay.Api.Models.Event { EventName = "", Venue = "", Province = "Gauteng", EventType = "Run" };
        var results = new List<ValidationResult>();
        var valid = Validator.TryValidateObject(ev, new ValidationContext(ev), results, validateAllProperties: true);
        Assert.False(valid);
        Assert.Contains(results, r => r.MemberNames.Contains(nameof(RaceDay.Api.Models.Event.EventName)));
        Assert.Contains(results, r => r.MemberNames.Contains(nameof(RaceDay.Api.Models.Event.Venue)));
    }
}
