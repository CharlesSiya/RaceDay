# RaceDay Part 3 – MVC application

The ASP.NET Core MVC application consumes the Part 2 REST API through a server-side `HttpClient`. It does not connect directly to SQL Server and does not contain a second copy of the API business logic.

## Prerequisites
- .NET 10 SDK
- SQL Server with the RaceDay database from Part 2
- Part 2 API configured and running
- An Azure Storage account for image uploads (optional while developing non-image features)

## Database update
Run `PART 3/Database_Part3_Images.sql` against the existing `RaceDayDB` database. This adds `Users.ProfileImageUrl` and `Events.BannerImageUrl` for the image URLs returned by the API.

## Configure the API URL
Edit `appsettings.json` and set `ApiSettings:BaseUrl` to the actual API URL shown in the API terminal or `Properties/launchSettings.json`. Keep the trailing slash. The current `https://localhost:7001/` value is only a development example; replace it if your API uses another port.

## Run locally
1. Open the API project in Visual Studio and start it first.
2. Open a terminal in this folder (`PART 3/RaceDay.Mvc`).
3. Run `dotnet restore`.
4. Run `dotnet build`.
5. Run `dotnet run`.
6. Open the MVC URL printed in the terminal.

## Azure Blob Storage configuration
Do not commit Azure credentials. Configure the API using a user secret or environment variables:

```powershell
dotnet user-secrets init --project "PART 2/RaceDay_Part2/RaceDay.Api/RaceDay.Api.csproj"
dotnet user-secrets set "AzureBlobStorage:ConnectionString" "YOUR_STORAGE_CONNECTION_STRING" --project "PART 2/RaceDay_Part2/RaceDay.Api/RaceDay.Api.csproj"
dotnet user-secrets set "AzureBlobStorage:ContainerName" "raceday-images" --project "PART 2/RaceDay_Part2/RaceDay.Api/RaceDay.Api.csproj"
```

The API accepts JPG, JPEG, PNG and WEBP images up to 5 MB. The MVC app sends the image to the API; only the API communicates with Azure Blob Storage. The API stores the returned image URL in SQL Server.

## Docker
Build from this directory:

```bash
docker build -t raceday-mvc .
```

Run the container, replacing the API host and port with the HTTP address reachable from Docker:

```bash
docker run --rm -p 8080:8080 -e ApiSettings__BaseUrl=http://host.docker.internal:5080/ raceday-mvc
```

The API must be running and reachable at the configured address. For Docker Desktop, `host.docker.internal` points from the container to the host computer. If the API itself runs in another container, use its Compose service name and internal port instead.

## Features in this implementation
- Registration and login through the API; MVC session stores user ID, role and the API authentication cookie.
- Role-specific Organiser and Participant navigation.
- Public event catalogue, event search/type filtering and event details.
- Organiser dashboard, event create/edit/delete, category create/delete, enrolment review and result capture.
- Participant enrolments, personal results and profile editing.
- Event banner and profile picture uploads forwarded from MVC to the API and Azure Blob Storage.
- Bootstrap responsive styling and a multi-stage Dockerfile.

## CI/CD and submission evidence
The repository-root workflow is `.github/workflows/raceday-ci.yml`. It restores and builds the API, tests and MVC project, then runs the unit tests. A green build must be confirmed on GitHub after pushing; do not use a fabricated screenshot.

Add your actual unlisted YouTube demonstration link here after recording your own voiceover: **[Insert your YouTube link]**.

Add a screenshot of the actual successful GitHub Actions run here before submission.

## AI assistance disclosure
AI assistance was used to help review the starter project, scaffold implementation examples and troubleshoot code. The student must review, adapt, run, test and understand the final code and disclose this assistance as required by the assignment.
